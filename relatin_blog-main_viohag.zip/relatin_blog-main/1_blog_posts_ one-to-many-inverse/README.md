One to Many and Inverse

posts
comments


one post has many comments ( one to many )
one comment belogs to one post ( inverse )


